package ma.enset.designpatterns.oberver;

import java.util.ArrayList;
import java.util.List;

public class Joueur implements Sujet{

    private int score;
    private List<Observer> observers = new ArrayList<>();

    public void setScore(int score){
        this.score = score;
        notifierObserver();
    }

    @Override
    public void ajouterObserver(Observer observer){
        observers.add(observer);
    }

    @Override
    public void supprimerObserver(Observer observer){
        observers.remove(observer);
    }
    @Override
    public void notifierObserver(){
        for (Observer o : observers){
            o.update(score);
        }
    }
}
