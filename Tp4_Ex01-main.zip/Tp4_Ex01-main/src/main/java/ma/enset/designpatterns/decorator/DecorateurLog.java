package ma.enset.designpatterns.decorator;

public class DecorateurLog extends Decorateur {

    public DecorateurLog(Composant composant) {
        super(composant);
    }

    @Override
    public void traitement() {
        System.out.println("Avant traitement");
        composant.traitement();
        System.out.println("Apres traitement");
    }
}
