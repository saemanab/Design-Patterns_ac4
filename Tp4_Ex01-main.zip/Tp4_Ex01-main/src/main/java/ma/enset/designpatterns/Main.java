package ma.enset.designpatterns;

import ma.enset.designpatterns.composite.Cercle;
import ma.enset.designpatterns.composite.GroupeFigures;
import ma.enset.designpatterns.composite.Rectangle;
import ma.enset.designpatterns.decorator.Composant;
import ma.enset.designpatterns.decorator.ComposantConcret;
import ma.enset.designpatterns.decorator.DecorateurLog;
import ma.enset.designpatterns.oberver.Camera;
import ma.enset.designpatterns.oberver.Couloir;
import ma.enset.designpatterns.oberver.Gardien;
import ma.enset.designpatterns.oberver.Joueur;
import ma.enset.designpatterns.template.Plugin;
import ma.enset.designpatterns.template.PluginFactory;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        //Composite
        GroupeFigures groupe = new GroupeFigures();
        groupe.ajouterfigures(new Cercle());
        groupe.ajouterfigures(new Rectangle());
        groupe.dessiner();

        //Template
        Plugin plugin = PluginFactory.getPlugin(
                "ma.enset.designpatterns.template.PluginImplA"
        );
        plugin.executer();

        //Decorator
        Composant c = new DecorateurLog(new ComposantConcret());
        c.traitement();

        //Observer
        Joueur joueur = new Joueur();
        joueur.ajouterObserver(new Camera());
        joueur.ajouterObserver(new Couloir());
        joueur.ajouterObserver(new Gardien());
        joueur.setScore(10);
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.

    }
}