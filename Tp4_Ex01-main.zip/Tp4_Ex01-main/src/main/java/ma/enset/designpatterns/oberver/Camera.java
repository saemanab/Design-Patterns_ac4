package ma.enset.designpatterns.oberver;

public class Camera implements Observer {
    @Override
    public void update(int score){
        System.out.println("Caméra : score = " +score);
    }
}
