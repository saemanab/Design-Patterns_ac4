package ma.enset.designpatterns.decorator;

public abstract class Decorateur implements Composant {
    protected Composant composant;

    public Decorateur(Composant composant) {
        this.composant = composant;
    }


}
