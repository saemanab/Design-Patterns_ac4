package ma.enset.designpatterns.composite;

public class Cercle implements Figure {
    @Override
    public void dessiner(){
        System.out.println("Dessiner un cercle.");
    }
}
