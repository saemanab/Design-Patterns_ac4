package ma.enset.designpatterns.oberver;

public class Gardien implements Observer {

    @Override
    public void update(int score){
        System.out.println("Gardien : score = " + score);
    }
}
