package ma.enset.designpatterns.oberver;

public interface Observer {
       void update(int core);
}
