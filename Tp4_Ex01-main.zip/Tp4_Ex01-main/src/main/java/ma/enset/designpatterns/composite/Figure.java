package ma.enset.designpatterns.composite;

public interface Figure {
    void dessiner();
}
