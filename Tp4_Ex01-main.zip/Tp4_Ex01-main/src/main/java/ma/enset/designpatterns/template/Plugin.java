package ma.enset.designpatterns.template;

public abstract class Plugin {
    public final void executer(){
        partie1();
        partie2();
    }

    protected abstract void partie1();
    protected abstract void partie2();

}
