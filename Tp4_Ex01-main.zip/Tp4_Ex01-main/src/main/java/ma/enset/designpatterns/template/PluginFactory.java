package ma.enset.designpatterns.template;

public class PluginFactory {
    public static Plugin getPlugin(String className) throws Exception {
        Class<?> clazz = Class.forName(className);
        return (Plugin) clazz.getDeclaredConstructor().newInstance();
    }
}
