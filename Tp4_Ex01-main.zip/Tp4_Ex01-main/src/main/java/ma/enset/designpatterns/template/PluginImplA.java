package ma.enset.designpatterns.template;

public class PluginImplA extends Plugin {

    @Override
    protected void partie1() {
        System.out.println("Partie1 - Impl A");
    }

    @Override
    protected void partie2(){
        System.out.println("Partie2 - Impl A");
    }

}
