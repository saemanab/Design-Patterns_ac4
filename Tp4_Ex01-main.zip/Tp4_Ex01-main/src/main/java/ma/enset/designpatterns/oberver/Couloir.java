package ma.enset.designpatterns.oberver;

public class Couloir {
}
