package ma.enset.designpatterns.composite;

public class Rectangle implements Figure{
    @Override
    public void dessiner(){
        System.out.println("Dessiner un rectangle");
    }
}
