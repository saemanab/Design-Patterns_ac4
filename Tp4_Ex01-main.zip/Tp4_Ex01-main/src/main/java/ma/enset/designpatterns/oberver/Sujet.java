package ma.enset.designpatterns.oberver;

public interface Sujet {
    void ajouterObserver(Observer observer);
    void supprimerObserver(Observer observer);
    void notifierObserver();
}
