package ma.enset.designpatterns.decorator;

public interface Composant {
    void traitement();
}
