package ma.enset.designpatterns.composite;

import java.util.ArrayList;
import java.util.List;

public class GroupeFigures implements Figure{
    private List<Figure> figures = new ArrayList<>();

    public void ajouterfigures(Figure figure){
        figures.add(figure);
    }

    @Override
    public void dessiner() {
        System.out.println("Groupe de figures :");
        for (Figure f : figures){
            f.dessiner();
        }
    }
}
